package com.example.christbot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Homepage extends AppCompatActivity {
   ImageView logo,p1,p2,e1,e2;
   TextView uid,apt_test,sem,job;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        String regno=getIntent().getStringExtra("regno");
        uid=findViewById(R.id.RegNo);
        uid.setText(regno);
        logo=findViewById(R.id.logo);
        apt_test=findViewById(R.id.aptitude_tests);
        sem=findViewById(R.id.seminar_info);
        job=findViewById(R.id.job_details);
        p1=findViewById(R.id.phone1);
        p2=findViewById(R.id.phone2);
        e1=findViewById(R.id.email1);
        e2=findViewById(R.id.email2);
        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String webpageUrl = "https://kp.christuniversity.in/KnowledgePro/StudentLogin.do";
                Uri webpageUri = Uri.parse(webpageUrl);
                Intent webpageIntent = new Intent(Intent.ACTION_VIEW, webpageUri);
                startActivity(webpageIntent);
            }
        });
        apt_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(Homepage.this, testpage.class);
                startActivity(intent);
            }
        });
        sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Homepage.this, seminar.class);
                startActivity(intent);
            }
        });
        job.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Homepage.this, job_info.class);
                startActivity(intent);
            }
        });
        p1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber1 = "6204081417";
                Uri phoneUri = Uri.parse("tel:" + phoneNumber1);
                Intent dialIntent = new Intent(Intent.ACTION_DIAL, phoneUri);
                startActivity(dialIntent);
            }
        });
        p2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber2 = "9523835835";
                Uri phoneUri1 = Uri.parse("tel:" + phoneNumber2);
                Intent dialIntent1 = new Intent(Intent.ACTION_DIAL, phoneUri1);
                startActivity(dialIntent1);
            }
        });
        e1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailAddress1 = "singh.aniket1406@gmail.com";
                Uri emailUri = Uri.parse("mailto:" + emailAddress1);
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, emailUri);
//                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject of the email"); Optional subject
//                emailIntent.putExtra(Intent.EXTRA_TEXT, "Body of the email"); Optional body
                emailIntent.setPackage("com.google.android.gm"); // Specify Gmail package name
                startActivity(emailIntent);
                //startActivity(Intent.createChooser(emailIntent, "Send email"));
            }
        });
        e2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailAddress2 = "harsh00var@gmail.com";
                Uri emailUri1 = Uri.parse("mailto:" + emailAddress2);
                Intent emailIntent1 = new Intent(Intent.ACTION_SENDTO, emailUri1);
//                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject of the email"); Optional subject
//                emailIntent.putExtra(Intent.EXTRA_TEXT, "Body of the email"); Optional body
                emailIntent1.setPackage("com.google.android.gm"); // Specify Gmail package name
                startActivity(emailIntent1);
                //startActivity(Intent.createChooser(emailIntent1, "Send email"));
            }
        });

    }
}