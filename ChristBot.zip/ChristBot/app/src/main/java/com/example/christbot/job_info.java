package com.example.christbot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class job_info extends AppCompatActivity {
Button ga,hpa;
ImageView cu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_info);
        ga=findViewById(R.id.g_apply_btn);
        hpa=findViewById(R.id.hp_apply_btn);
        cu=findViewById(R.id.logo1);
        ga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String linkedInProfileUrl= "https://www.linkedin.com/company/google/?originalSubdomain=in";
                Uri linkedInProfileUri = Uri.parse(linkedInProfileUrl);
                Intent linkedInIntent = new Intent(Intent.ACTION_VIEW, linkedInProfileUri);
                startActivity(linkedInIntent);
            }
        });
        hpa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String linkedInProfileUrl1= "https://www.linkedin.com/company/hewlett-packard-enterprise/";
                Uri linkedInProfileUri1 = Uri.parse(linkedInProfileUrl1);
                Intent linkedInIntent1 = new Intent(Intent.ACTION_VIEW, linkedInProfileUri1);
                startActivity(linkedInIntent1);
            }
        });
        cu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(job_info.this, Homepage.class);
                startActivity(intent);
            }
        });
    }
}