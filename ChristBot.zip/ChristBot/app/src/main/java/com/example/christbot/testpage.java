package com.example.christbot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class testpage extends AppCompatActivity {
TextView pt1,pt2,check_1,check_2;
ImageView cu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testpage);
        pt1=findViewById(R.id.pt_1);
        pt2=findViewById(R.id.pt_2);
        check_1=findViewById(R.id.check1);
        check_2=findViewById(R.id.check2);
        cu=findViewById(R.id.logo1);
        check_1.setText("");
        check_2.setText("");
        cu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(testpage.this, Homepage.class);
                startActivity(intent);
            }
        });
        pt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String val="Attempted";
                String googleFormUrl = "https://www.indiabix.com/online-test/aptitude-test/1";
                Uri googleFormUri = Uri.parse(googleFormUrl);
                Intent googleFormIntent = new Intent(Intent.ACTION_VIEW, googleFormUri);
                startActivity(googleFormIntent);
                check_1.setText(val);
            }
        });
        pt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String val1="Attempted";
                String googleFormUrl1 = "https://www.indiabix.com/online-test/aptitude-test/2";
                Uri googleFormUri = Uri.parse(googleFormUrl1);
                Intent googleFormIntent = new Intent(Intent.ACTION_VIEW, googleFormUri);
                startActivity(googleFormIntent);
                check_2.setText(val1);
            }
        });

    }
}