package com.example.a2247214_cat3;
public class MyModel {
    private int imageResource;
    private String heading;

    public MyModel(int imageResource, String heading) {
        this.imageResource = imageResource;
        this.heading = heading;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getHeading() {
        return heading;
    }
}
