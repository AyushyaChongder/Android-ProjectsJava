package com.example.travex;

public interface OnLoginListener {
    void onLogin(String email, String password);
}

