package com.example.myhealth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class displaypage extends AppCompatActivity {
TextView uid1,uid2,uid3,uid4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displaypage);
        String uname = getIntent().getStringExtra("name");
        String uemail = getIntent().getStringExtra("email");
        String uphone = getIntent().getStringExtra("phone");
        String uage = getIntent().getStringExtra("age");
        uid1 = findViewById(R.id.dname);
        uid1.setText(uname);
        uid2 = findViewById(R.id.demail);
        uid2.setText(uemail);
        uid3 = findViewById(R.id.dphone);
        uid3.setText(uphone);
        uid4 = findViewById(R.id.dage);
        uid4.setText(uage);
    }
}