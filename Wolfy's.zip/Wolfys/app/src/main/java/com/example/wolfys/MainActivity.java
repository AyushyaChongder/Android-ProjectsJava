package com.example.wolfys;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button started;
    Dialog currentDialog; // To keep track of the currently displayed dialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        started = findViewById(R.id.bottomsheet1);
        started.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(true); // Show sign up bottom sheet
            }
        });
    }

    private void showDialog(boolean isSignUp) {
        if (currentDialog != null && currentDialog.isShowing()) {
            currentDialog.dismiss(); // Dismiss the currently displayed dialog
        }

        currentDialog = new Dialog(this);
        currentDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        currentDialog.setContentView(isSignUp ? R.layout.signup_bottom_sheet : R.layout.login_bottom_sheet);
        currentDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        currentDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        currentDialog.getWindow().getAttributes().windowAnimations = R.style.DialoAnimation;
        currentDialog.getWindow().setGravity(Gravity.BOTTOM);

        if (isSignUp) {
            Button signupButton = currentDialog.findViewById(R.id.signup_main);
            signupButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle signup here
                    EditText nameEditText = currentDialog.findViewById(R.id.signup_name);
                    EditText emailEditText = currentDialog.findViewById(R.id.signup_email);
                    EditText passwordEditText = currentDialog.findViewById(R.id.signup_password);

                    String name = nameEditText.getText().toString();
                    String email = emailEditText.getText().toString();
                    String password = passwordEditText.getText().toString();

                    DatabaseHelper databaseHelper = new DatabaseHelper(MainActivity.this);
                    if(name.equals("") && email.equals("") && password.equals(""))
                    {
                       Toast.makeText(MainActivity.this, "Kindly fill in all the fields!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if (!databaseHelper.checkEmail(email)) {
                            if (databaseHelper.insertData(name, email, password)) {
                                Toast.makeText(MainActivity.this, "Signup Successful", Toast.LENGTH_SHORT).show();
                                currentDialog.dismiss();
                            } else {
                                Toast.makeText(MainActivity.this, "Signup Failed", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "Email already exists", Toast.LENGTH_SHORT).show();
                        }

                    }


                    databaseHelper.close();
                }
            });

            Button loginButton1 = currentDialog.findViewById(R.id.login); // Login button on signup bottom sheet
            loginButton1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDialog(false); // Show login bottom sheet
                }
            });
        } else {
            Button loginButton = currentDialog.findViewById(R.id.login_main);
            loginButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle login here
                    EditText emailEditText = currentDialog.findViewById(R.id.login_email);
                    EditText passwordEditText = currentDialog.findViewById(R.id.login_password);

                    String email = emailEditText.getText().toString();
                    String password = passwordEditText.getText().toString();

                    DatabaseHelper databaseHelper = new DatabaseHelper(MainActivity.this);

                    if (databaseHelper.checkEmailPassword(email, password)) {
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                        // Navigate to the homepage activity
                        Intent intent = new Intent(MainActivity.this, HomePage.class);
                        startActivity(intent);

                        currentDialog.dismiss();
                    } else {
                        Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }

                    databaseHelper.close();
                }
            });
        }

        currentDialog.show();
    }
}
