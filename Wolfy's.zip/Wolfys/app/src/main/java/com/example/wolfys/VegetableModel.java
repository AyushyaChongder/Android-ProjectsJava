package com.example.wolfys;

import android.os.Parcel;
import android.os.Parcelable;

public class VegetableModel implements Parcelable {
        private int id;
        private String title;
        private int imgId;
        private boolean isSelected;

        public int getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }

        public int getImgId() {
            return imgId;
        }

        public boolean isSelected() {
            return isSelected;
        }

        public void setSelected(boolean selected) {
            isSelected = selected;
        }

        public VegetableModel(int id, String title, int imgId) {
            this.id = id;
            this.title = title;
            this.imgId = imgId;
            this.isSelected = false;
        }
    // Parcelable implementation

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeInt(imgId);
        dest.writeByte((byte) (isSelected ? 1 : 0));
    }

    protected VegetableModel(Parcel in) {
        title = in.readString();
        imgId = in.readInt();
        isSelected = in.readByte() != 0;
    }

    public static final Creator<VegetableModel> CREATOR = new Creator<VegetableModel>() {
        @Override
        public VegetableModel createFromParcel(Parcel in) {
            return new VegetableModel(in);
        }

        @Override
        public VegetableModel[] newArray(int size) {
            return new VegetableModel[size];
        }
    };
}
